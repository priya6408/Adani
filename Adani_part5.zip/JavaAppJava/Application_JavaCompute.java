import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class Application_JavaCompute extends MbJavaComputeNode {
	
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		
		
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
			MbElement environment = outAssembly.getGlobalEnvironment().getRootElement();
			MbMessage env = outAssembly.getGlobalEnvironment();
			MbElement data = environment.getFirstElementByPath("Variables/VCD");
	        String passworddata = data.getValueAsString();
			String s = get_SHA_512_SecurePassword(passworddata);
			
			
			env.getRootElement().createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "JSONString", s);
	   			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) 	{
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}
	
	
	public String get_SHA_512_SecurePassword(String passwordToHash){
		String generatedPassword = null;
		String genSalt = "EbFwgzjS2F"; // salt
		    try {
		         MessageDigest md = MessageDigest.getInstance("SHA-512");
//		         md.update(genSalt.getBytes(StandardCharsets.UTF_8));
		         byte[] bytes = md.digest(passwordToHash.getBytes(StandardCharsets.UTF_8));
		         StringBuilder sb = new StringBuilder();
		         
		         for(int i=0; i< bytes.length ;i++){
		             sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
		          }
		          generatedPassword = sb.toString();
		        } 
		       catch (NoSuchAlgorithmException e){
		        e.printStackTrace();
		       }
		    return generatedPassword;
		}


}
