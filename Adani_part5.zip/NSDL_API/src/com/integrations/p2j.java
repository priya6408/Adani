package com.integrations;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.util.Enumeration;

public class p2j
{
	static String inputPFXFile;
	static String inputPwd;
	static String outputJKS;
    public static String generateKeyStore(String pfxFile, String pwd, String outputJKSFile)
    {
    	String signArgs[]  = new String[3];
    	signArgs[0] = pfxFile;
    	signArgs[1] = pwd;
    	signArgs[2] = outputJKSFile;
    	
    	if(signArgs.length < 1)
        {
            System.out.println("usage: java p2j certi.pfx pfxpswd oupt.jks");
            System.exit(1);
        }
        
        File fileIn = new File(signArgs[0]);
        File fileOut = null;
        if(signArgs.length == 3)
        {    fileOut = new File(signArgs[2]);

        }else{
        	System.out.println("usage: java p2j certi.pfx pfxpswd oupt.jks");
        System.exit(1);}
        if(!fileIn.canRead())
        {
            System.out.println("Unable to access input keystore: " + fileIn.getPath());
            System.exit(2);
        }
        if(fileOut.exists() && !fileOut.canWrite())
        {
            System.out.println("Output file is not writable: " + fileOut.getPath());
            System.exit(2);
        }
        KeyStore kspkcs12 = null;
		try {
			kspkcs12 = KeyStore.getInstance("pkcs12");
		} catch (KeyStoreException e) {
			e.printStackTrace();
		}
        KeyStore ksjks = null;
		try {
			ksjks = KeyStore.getInstance("jks");
		} catch (KeyStoreException e) {
			e.printStackTrace();
		}

        char inphrase[] = signArgs[1].toCharArray();
        char outphrase[] = signArgs[1].toCharArray();
        
        
        try {
			kspkcs12.load(new FileInputStream(fileIn), inphrase);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        try {
			ksjks.load(fileOut.exists() ? ((java.io.InputStream) (new FileInputStream(fileOut))) : null, outphrase);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        Enumeration eAliases = null;
		try {
			eAliases = kspkcs12.aliases();
		} catch (KeyStoreException e) {
			e.printStackTrace();
		}
        int n = 0;
        do
        {
            if(!eAliases.hasMoreElements())
                break;
            String strAlias = (String)eAliases.nextElement();
            try {
				if(kspkcs12.isKeyEntry(strAlias))
				{
				    java.security.Key key = kspkcs12.getKey(strAlias, inphrase);
				    Certificate chain[] = kspkcs12.getCertificateChain(strAlias);
				    ksjks.setKeyEntry(strAlias, key, outphrase, chain);
				}
			} catch (UnrecoverableKeyException e) {
				e.printStackTrace();
			} catch (KeyStoreException e) {
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			}
        } while(true);
        OutputStream out = null;
		try {
			out = new FileOutputStream(fileOut);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
        try {
			ksjks.store(out, outphrase);
		} catch (KeyStoreException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        try {
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
        System.out.println("Java Key Store created successfully");
    	return "";
    }

    public static void main(String args[])
        throws Exception
    {
    	 inputPFXFile = args[0];
    	
    	 inputPwd = args[1];
    	
    	 outputJKS = args[2];
    	 generateKeyStore(inputPFXFile, inputPwd, outputJKS);
        
    }
}
