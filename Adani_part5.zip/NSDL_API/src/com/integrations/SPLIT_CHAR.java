package com.integrations;

import java.util.StringTokenizer;

public class SPLIT_CHAR {
	static String inputData;
	static String outputData;
	public static String SplitString(String input) {
		String in = input;
		StringTokenizer tokenizer = new StringTokenizer(in, "^");
		StringBuilder sb  = new StringBuilder();
		
		System.out.println(tokenizer.countTokens());
		int j = 0;
		int k = 0;
		while (tokenizer.hasMoreTokens()) {
			if(k == 0){
				tokenizer.nextToken();
			}
			String data = tokenizer.nextToken();
			
			sb.append(data+" ");
			k++;
		}
		System.out.println(sb.toString());
		return sb.toString();
	}

	public static void main(String args[]) {
		inputData = args[0];
		SplitString(inputData);

	}
}
