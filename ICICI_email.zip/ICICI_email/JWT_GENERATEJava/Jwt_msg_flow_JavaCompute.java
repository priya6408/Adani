import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
//import org.apache.commons.codec.binary.Hex;

public class Jwt_msg_flow_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
			MbElement environment = outAssembly.getGlobalEnvironment().getRootElement();
			MbMessage env = outAssembly.getGlobalEnvironment();
			MbElement UN = environment.getFirstElementByPath("Variables/username");
			MbElement Pass = environment.getFirstElementByPath("Variables/password");
	        String passworddata = Pass.getValueAsString();
			String s = get_SHA_256_SecurePassword(passworddata);

			env.getRootElement().createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "JSONString", s);

			
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

public String get_SHA_256_SecurePassword(String passwordToHash){
		
		//String salt = "abc123";
		String generatedPassword = null;
        try {
        	MessageDigest digest = MessageDigest.getInstance("SHA-256");
        	byte[] encodedhash = digest.digest(
        	  passwordToHash.getBytes(StandardCharsets.UTF_8));
            StringBuffer sb = new StringBuffer();
            for(int i=0; i< encodedhash.length ;i++){
            	String hex = Integer.toHexString(0xff & encodedhash[i]);
                if(hex.length() == 1) sb.append('0');
                    sb.append(hex);
            }
            generatedPassword = sb.toString();
           
        }
        catch (NoSuchAlgorithmException e){
            e.printStackTrace();
        }
       
		return generatedPassword;
		
	}
	
	
}
