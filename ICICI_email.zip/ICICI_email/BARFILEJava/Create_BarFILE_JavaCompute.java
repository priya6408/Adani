import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;


public class Create_BarFILE_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
			MbElement environment = outAssembly.getGlobalEnvironment().getRootElement();
			MbMessage env = outAssembly.getGlobalEnvironment();
			MbElement input = outAssembly.getMessage().getRootElement();
			 
			
			String workspace_name = null;
			String bar_name = null;
			String application_name = null;
			String library_name = null;
			String execution_group = null;
			
			MbElement workspacename = environment.getFirstElementByPath("Variables/workspace_name");
			MbElement barname = environment.getFirstElementByPath("Variables/bar_name");
			MbElement applicationname = environment.getFirstElementByPath("Variables/application_name");
			MbElement libraryname = environment.getFirstElementByPath("Variables/library_name");
			MbElement executiongroup = environment.getFirstElementByPath("Variables/execution_group");
			
			execution_group = executiongroup.getValueAsString();
			workspace_name = workspacename.getValueAsString();
			bar_name = barname.getValueAsString() + "_" + execution_group ;
			application_name = applicationname.getValueAsString();
			library_name = libraryname.getValueAsString();
			
			
			String reqbody = "mqsicreatebar -data " + workspace_name +  " -b "+ bar_name + " -a " + application_name;
			
			
			
			
			
			Process p = Runtime.getRuntime().exec(reqbody);
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
			BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));	
			String s;
			while ((s = stdInput.readLine()) != null) {
				env.getRootElement().createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "Correct", s);
            }
			
			
	            while ((s = stdError.readLine()) != null) {
	            	env.getRootElement().createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "Wrong", s);
	            }
		
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

}
