package org.apache.commons.codec.binary;

public class Hex {

}
