package com.integrations;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;

import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.util.encoders.Base64;

public class pkcs7gen {
	static String jksFile;
	static String pwd;
	static String data;
	static String output1;
	public static String generateSign (String jksInput, String pwd, String dataToBeSigned, String ouptSignFile){
		String signArgs[]  = new String[4];
		signArgs[0] = jksInput;
		signArgs[1] = pwd;
		signArgs[2] = dataToBeSigned;
		signArgs[3] = ouptSignFile;
		System.out.println("signArgs[0] - " + signArgs[0] + " signArgs[1] - " + signArgs[1] + " signArgs[2] - " +signArgs[0] +" signArgs[3] - "+signArgs[3]);
		
		if(signArgs.length < 3)
        {
            System.out.println("java pkcs7gen oupt.jks pfxpswd dataToBeSigned oupt.sig");
            System.exit(1);
        }
			KeyStore keystore = null;
			try {
				keystore = KeyStore.getInstance("jks");
			} catch (KeyStoreException e1) {
				e1.printStackTrace();
			}
			InputStream input = null;
			try {
				input = new FileInputStream(signArgs[0]);
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
			try {
				char[] password=signArgs[1].toCharArray();
				try {
					keystore.load(input, password);
				} catch (NoSuchAlgorithmException e1) {
					e1.printStackTrace();
				} catch (CertificateException e1) {
					e1.printStackTrace();
				}
			} catch (IOException e) {
			} finally {

			}
			Enumeration e = null;
			try {
				e = keystore.aliases();
			} catch (KeyStoreException e1) {
				e1.printStackTrace();
			}
			String alias = "";

			if(e!=null)
			{
				while (e.hasMoreElements())
				{
					String  n = (String)e.nextElement();
					try {
						if (keystore.isKeyEntry(n))
						{
							alias = n;
						}
					} catch (KeyStoreException e1) {
						e1.printStackTrace();
					}
				}
			}
			PrivateKey privateKey = null;
			try {
				privateKey = (PrivateKey) keystore.getKey(alias, signArgs[1].toCharArray());
			} catch (UnrecoverableKeyException e1) {
				e1.printStackTrace();
			} catch (KeyStoreException e1) {
				e1.printStackTrace();
			} catch (NoSuchAlgorithmException e1) {
				e1.printStackTrace();
			}
			X509Certificate myPubCert = null;
			try {
				myPubCert = (X509Certificate) keystore.getCertificate(alias);
			} catch (KeyStoreException e1) {
				e1.printStackTrace();
			}
			byte[] dataToSign=signArgs[2].getBytes();
			CMSSignedDataGenerator sgen = new CMSSignedDataGenerator();
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider ());
			System.out.println("signArgs[0] - " + signArgs[0] + " signArgs[1] - " + signArgs[1] + " signArgs[2] - " +signArgs[0] +" signArgs[3] - "+signArgs[3]);
			sgen.addSigner(privateKey, myPubCert,CMSSignedDataGenerator.DIGEST_SHA1);
			Certificate[] certChain = null;
			try {
				certChain = keystore.getCertificateChain(alias);
			} catch (KeyStoreException e1) {
				e1.printStackTrace();
			}
			ArrayList certList = new ArrayList();
			CertStore certs = null;
			for (int i=0; i < certChain.length; i++)
				certList.add(certChain[i]); 
			try {
				sgen.addCertificatesAndCRLs(CertStore.getInstance("Collection", new CollectionCertStoreParameters(certList), "BC"));
			} catch (CertStoreException e1) {
				e1.printStackTrace();
			} catch (NoSuchAlgorithmException e1) {
				e1.printStackTrace();
			} catch (NoSuchProviderException e1) {
				e1.printStackTrace();
			} catch (InvalidAlgorithmParameterException e1) {
				e1.printStackTrace();
			} catch (CMSException e1) {
				e1.printStackTrace();
			}
			CMSSignedData csd = null;
			try {
				csd = sgen.generate(new CMSProcessableByteArray(dataToSign),true, "BC");
			} catch (NoSuchAlgorithmException e2) {
				e2.printStackTrace();
			} catch (NoSuchProviderException e2) {
				e2.printStackTrace();
			} catch (CMSException e2) {
				e2.printStackTrace();
			}
			byte[] signedData = null;
			try {
				signedData = csd.getEncoded();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			byte[] signedData64 = Base64.encode(signedData); 
			FileOutputStream out = null;
			try {
				out = new FileOutputStream(signArgs[3]);
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
			try {
				out.write(signedData64);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			try {
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			} 
			System.out.println("Signature file written to "+signArgs[3]);
		return "Signature file written successfully and ";
	}
	public static void main(String args[]) throws Exception {
	jksFile = args[0];
	pwd = args[1];
	data = args[2];
	output1 = args[3];
	System.out.println("jks file - " + jksFile + "pwd - " + pwd + "data - " +data +"output1 - "+output1);
	generateSign(jksFile, pwd, data, output1);

		}

	
	}
