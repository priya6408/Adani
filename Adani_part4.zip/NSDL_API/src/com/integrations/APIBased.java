package com.integrations;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Date;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;


public class APIBased {

	static String panInqData;
	static String panInqSign;
	static String output;
	public static class DummyTrustManager implements X509TrustManager {

		public DummyTrustManager() {
		}

		public boolean isClientTrusted(X509Certificate cert[]) {
			return true;
		}

		public boolean isServerTrusted(X509Certificate cert[]) {
			return true;
		}

		public X509Certificate[] getAcceptedIssuers() {
			return new X509Certificate[0];
		}

		public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

		}

		public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

		}
	}
	public static class DummyHostnameVerifier implements HostnameVerifier {

		public boolean verify( String urlHostname, String certHostname ) {
			return true;
		}

		public boolean verify(String arg0, SSLSession arg1) {
			return true;
		}
	}
	public static String panInq(String panData, String panSignature){
		String signArgs[]  = new String[2];
		signArgs[0] = panData;
		signArgs[1] = panSignature;
		Date startTime=null;
		Calendar c1=Calendar.getInstance();
		startTime=c1.getTime();

		Date connectionStartTime=null;
		String logMsg="\n-";
		BufferedWriter out=null;
		FileWriter fstream=null;
		Calendar c=Calendar.getInstance();
		long nonce=c.getTimeInMillis();

		String urlOfNsdl="https://59.163.46.2/TIN/PanInquiryBackEnd";
		//String urlOfNsdl="https://121.240.9.19/TIN/PanInquiryBackEnd";
		String data=null;
		String signature=null;


	    try {
	    	data = signArgs[0];
	    	signature = signArgs[1];
	    //	System.out.println("data "+data);
	    	//System.out.println("signature "+signature);

	    } catch (Exception e) {
	    	logMsg+="::Exception: "+e.getMessage()+" ::Program Start Time:"+startTime+"::nonce= "+nonce;
	    }

		try{
			fstream= new FileWriter("API_PAN_verification.logs",true);
			out = new BufferedWriter(fstream);
		}
		catch(Exception e){
			logMsg+="::Exception: "+e.getMessage()+" ::Program Start Time:"+startTime+"::nonce= "+nonce;
			try {
				out.write(logMsg);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			try {
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		SSLContext sslcontext = null;
		try {
			sslcontext = SSLContext.getInstance("TLSv1.2");

			sslcontext.init(new KeyManager[0],
					new TrustManager[] { new DummyTrustManager() },
					new SecureRandom());
		} catch (NoSuchAlgorithmException e) {
			logMsg+="::Exception: "+e.getMessage()+" ::Program Start Time:"+startTime+"::nonce= "+nonce;
			e.printStackTrace(System.err);
			try {
				out.write(logMsg);
			} catch (IOException e2) {
				e2.printStackTrace();
			}
			try {
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (KeyManagementException e) {
			logMsg+="::Exception: "+e.getMessage()+" ::Program Start Time:"+startTime+"::nonce= "+nonce;
			e.printStackTrace(System.err);
			try {
				out.write(logMsg);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			try {
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

		SSLSocketFactory factory = sslcontext.getSocketFactory();


		String urlParameters="data=";
		try{
			urlParameters =urlParameters + URLEncoder.encode(data, "UTF-8") +"&signature=" + URLEncoder.encode(signature, "UTF-8");
		}catch(Exception e){
			logMsg+="::Exception: "+e.getMessage()+" ::Program Start Time:"+startTime+"::nonce= "+nonce;
			e.printStackTrace();
			try {
				out.write(logMsg);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			try {
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

		try{
			URL url;
			HttpsURLConnection connection;
			InputStream is = null;


			String ip=urlOfNsdl;
			url = new URL(ip);
			System.out.println("URL "+ip);
			connection = (HttpsURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
			connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
			connection.setRequestProperty("Content-Language", "en-US");
			connection.setUseCaches (false);
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setSSLSocketFactory(factory);
			connection.setHostnameVerifier(new DummyHostnameVerifier());
			OutputStream os = connection.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			osw.write(urlParameters);
			osw.flush();
			connectionStartTime=new Date();
			logMsg+="::Request Sent At: " + connectionStartTime;
			logMsg+="::Request Data: "+ data;
			osw.close();
			is =connection.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(is));
			String line =null;
			line = in.readLine();
			System.out.println("Output: "+line);
			output = line;
			is.close();
			in.close();
		}
		catch(ConnectException e){
			logMsg+="::Exception: "+e.getMessage() + "::Program Start Time:"+startTime+"::nonce= "+nonce;
			try {
				out.write(logMsg);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			try {
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		catch(Exception e){
			logMsg+="::Exception: "+e.getMessage()+ "::Program Start Time:"+startTime+"::nonce= "+nonce;
			try {
				out.write(logMsg);
			} catch (IOException e2) {
				e2.printStackTrace();
			}
			try {
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}

		try {
			out.write(logMsg);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return output;
	}
	public static void main(String[] args) throws Exception{
			
		panInqData = args[0];
		panInqSign = args[1];
		panInq(panInqData, panInqSign);
	}
}
